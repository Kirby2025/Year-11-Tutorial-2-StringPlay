 T# Year-11-CS-Unit-1-Tutorial-StringPlay

Topic 1 - Primitive Types, Strings, and Scanner		
									
Tutorial 2 - String Play

When we wish to output a value to the console, we use the statement:

System.out.print(insertValueThatYouWishToPrintHere) to print on the same line.
System.out.println(insertValueThatYouWishToPrintHere) to print on different lines.

In intelliJ, a neat shortcut for the print statement is to type “sout” and press enter.
